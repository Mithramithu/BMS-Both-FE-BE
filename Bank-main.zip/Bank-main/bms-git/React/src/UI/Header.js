import React from 'react'; 
// import { Form, Button, Row ,Col} from 'react-bootstrap';
import './hf.css';
// import EditProfile from '../components/Profile/EditProfile';
// import { Switch, Route } from 'react-router-dom';
const Header = () => {

  
  return (
    <div className="Header">
      BMS
    {/* <Switch>
      <Route exact path = "/profile" component = {EditProfile} />
    </Switch> */}
    </div>
    
  )
}

export default Header;